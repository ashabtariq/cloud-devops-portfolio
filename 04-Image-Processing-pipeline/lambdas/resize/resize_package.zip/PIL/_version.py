# Master version for Pillow
from __future__ import annotations

__version__ = "11.3.0"
